/* Root app — state machine + Tweaks panel */

const { useState: useS, useEffect: useE, useRef: useR, useMemo: useM, useCallback: useC } = React;

// Default tweaks
const DEFAULTS = /*EDITMODE-BEGIN*/{
  "feltHue": "purple",
  "cardBackTheme": "ornate",
  "animationIntensity": "heavy",
  "fanLayout": "fanned",
  "compareScreen": "bars"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(DEFAULTS);

  // Apply tweak side-effects (theme hue etc)
  useE(() => {
    const root = document.documentElement;
    const hues = {
      purple: { bg: '#1a0a4a', dark: '#100432', light: '#2e1370', deepest: '#06021a', glow: '#3d1ba0' },
      magenta:{ bg: '#3a0a3d', dark: '#260628', light: '#5e1666', deepest: '#1a0218', glow: '#7a2080' },
      teal:   { bg: '#0a2a3a', dark: '#06182a', light: '#10405a', deepest: '#03101a', glow: '#1a6a8a' },
      crimson:{ bg: '#3a0a1f', dark: '#260614', light: '#5e1632', deepest: '#1a020a', glow: '#7a204a' },
    };
    const c = hues[tweaks.feltHue] || hues.purple;
    root.style.setProperty('--bg', c.bg);
    root.style.setProperty('--bg-dark', c.dark);
    root.style.setProperty('--bg-light', c.light);
    root.style.setProperty('--bg-deepest', c.deepest);
    root.style.setProperty('--bg-glow', c.glow);
  }, [tweaks.feltHue]);

  // ----- screen state -----
  const [screen, setScreen] = useS('splash'); // splash | lobby | waiting | game | gameover
  const [name, setName] = useS('');
  const [roomCode, setRoomCode] = useS('');
  const [numPlayers, setNumPlayers] = useS(2);
  const [cardsPerPlayer, setCardsPerPlayer] = useS(10);

  // ----- game state -----
  const [players, setPlayers] = useS([]);
  const [hands, setHands] = useS([]);
  const [round, setRound] = useS(1);
  const [currentPlayer, setCurrentPlayer] = useS(0);
  const [timer, setTimer] = useS(30);
  const [comparison, setComparison] = useS(null);
  const [winner, setWinner] = useS(null);
  const [shaking, setShaking] = useS(false);
  const rootRef = useR(null);

  // ---- timer countdown ----
  useE(() => {
    if (screen !== 'game' || comparison || winner != null) return;
    if (timer <= 0) {
      // auto-tap a random stat for the current player
      autoTapStat();
      return;
    }
    const t = setTimeout(() => setTimer(t => t - 1), 1000);
    return () => clearTimeout(t);
  }, [timer, screen, comparison, winner]);

  // ---- AI: when it's not your turn, take a turn after a delay ----
  useE(() => {
    if (screen !== 'game' || comparison || winner != null) return;
    if (currentPlayer === 0) return;
    const t = setTimeout(() => {
      autoTapStat();
    }, 1400 + Math.random() * 1200);
    return () => clearTimeout(t);
  }, [currentPlayer, screen, comparison, winner]);

  function autoTapStat() {
    const hand = hands[currentPlayer];
    if (!hand || !hand.length) return;
    const top = hand[0];
    // pick best stat
    let best = TC.STATS[0].key, bestVal = -1;
    for (const s of TC.STATS) {
      if (top[s.key] > bestVal) { bestVal = top[s.key]; best = s.key; }
    }
    // randomise slightly
    if (Math.random() < 0.3) best = TC.STATS[Math.floor(Math.random() * TC.STATS.length)].key;
    handleStatTap(best);
  }

  // ---- start a game ----
  function startGame(code, np, cpp) {
    const allHands = TC.dealHands(np, cpp, Date.now());
    const playerObjs = [];
    playerObjs.push({ name, isYou: true });
    const others = ['Akira', 'Yuki', 'Ren'];
    for (let i = 1; i < np; i++) playerObjs.push({ name: others[i - 1] || `Player ${i + 1}` });
    setPlayers(playerObjs);
    setHands(allHands);
    setRound(1);
    setCurrentPlayer(0);
    setTimer(30);
    setComparison(null);
    setWinner(null);
    setRoomCode(code);
    setScreen('game');
  }

  // ---- handle stat tap ----
  function handleStatTap(statKey) {
    if (comparison) return;
    // Build comparison between current player & next player
    // For simplicity (and visual clarity) compare current vs the "best opponent" each round —
    // top cards of all players are revealed, but visualize 2-card head-to-head if 2 players,
    // otherwise show all
    const topCards = hands.map(h => h[0]).filter(Boolean);
    if (topCards.length < 2) return;

    // Find winner across all top cards on this stat
    let winnerIdx = 0;
    let bestVal = -1;
    topCards.forEach((c, i) => {
      if (c[statKey] > bestVal) { bestVal = c[statKey]; winnerIdx = i; }
    });

    // For UI we pass the two most-relevant cards: current player & best opponent (or just first two)
    // If 2 players: simply 0 vs 1
    let leftIdx = currentPlayer;
    let rightIdx = currentPlayer === 0 ? 1 : 0;
    // Re-resolve winnerIdx as 0 or 1 in this pair to match UI
    const leftCard = topCards[leftIdx];
    const rightCard = topCards[rightIdx];
    const lVal = leftCard[statKey];
    const rVal = rightCard[statKey];
    let pairWinner;
    if (lVal === rVal) pairWinner = -1; // tie
    else pairWinner = lVal > rVal ? 0 : 1;

    setComparison({
      cards: [leftCard, rightCard],
      stat: statKey,
      winnerIdx: pairWinner,   // 0 = left wins, 1 = right wins, -1 = tie
      leftIdx, rightIdx,
      globalWinnerIdx: winnerIdx,
    });

    // Screen shake on heavy + winner == you
    if (tweaks.animationIntensity === 'heavy' && pairWinner === 0) {
      setShaking(true);
      setTimeout(() => setShaking(false), 500);
    }
  }

  // ---- after comparison done, resolve round ----
  function onCompareDone() {
    if (!comparison) return;

    // Move both compared top cards to winner's hand (bottom)
    const winnerGlobalIdx = comparison.winnerIdx === 0 ? comparison.leftIdx
                          : comparison.winnerIdx === 1 ? comparison.rightIdx
                          : comparison.leftIdx; // tie -> left keeps

    const newHands = hands.map(h => h.slice());
    const collectedCards = [];
    // pop tops from all players' decks for this round
    for (let i = 0; i < newHands.length; i++) {
      if (newHands[i].length) collectedCards.push(newHands[i].shift());
    }
    newHands[winnerGlobalIdx] = newHands[winnerGlobalIdx].concat(collectedCards);

    setHands(newHands);
    setComparison(null);
    setRound(r => r + 1);
    setTimer(30);
    setCurrentPlayer(winnerGlobalIdx);

    // Check for game over
    const survivors = newHands.filter(h => h.length > 0).length;
    if (survivors === 1) {
      const w = newHands.findIndex(h => h.length > 0);
      setTimeout(() => setWinner(w), 700);
    }
  }

  // ---- screens ----
  let view;
  if (screen === 'splash') {
    view = <SplashScreen onSubmit={(n) => { setName(n); setScreen('lobby'); }} />;
  } else if (screen === 'lobby') {
    view = (
      <LobbyScreen
        name={name}
        onCreate={(np, cpp) => {
          setNumPlayers(np); setCardsPerPlayer(cpp);
          setRoomCode(TC.genRoomCode());
          setScreen('waiting');
        }}
        onJoin={(code) => {
          setRoomCode(code);
          setNumPlayers(2); setCardsPerPlayer(10);
          setScreen('waiting');
        }}
        onLeave={() => setScreen('splash')}
      />
    );
  } else if (screen === 'waiting') {
    view = (
      <GameLobbyScreen
        name={name}
        code={roomCode}
        numPlayers={numPlayers}
        cardsPerPlayer={cardsPerPlayer}
        onStart={() => startGame(roomCode, numPlayers, cardsPerPlayer)}
        onLeave={() => setScreen('lobby')}
      />
    );
  } else if (screen === 'game') {
    if (winner != null) {
      view = (
        <GameOverScreen
          players={players}
          winnerIdx={winner}
          youIdx={0}
          onPlayAgain={() => { setScreen('lobby'); setWinner(null); }}
          onChangeName={() => { setScreen('splash'); setWinner(null); setName(''); }}
        />
      );
    } else {
      view = (
        <GameScreen
          round={round}
          code={roomCode}
          players={players}
          hands={hands}
          currentPlayer={currentPlayer}
          timer={timer}
          onStatTap={handleStatTap}
          comparison={comparison}
          onCompareDone={onCompareDone}
        />
      );
    }
  }

  return (
    <div ref={rootRef} className={shaking ? 'shake' : ''} style={{ height: '100%', position: 'relative' }}>
      <div className="table-bg" />
      <SparkleLayer count={20} />
      {view}

      <TweaksUI tweaks={tweaks} setTweak={setTweak} />
    </div>
  );
}

// ============================================================
// Tweaks UI
// ============================================================
function TweaksUI({ tweaks, setTweak }) {
  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Theme">
        <TweakSelect
          label="Background"
          value={tweaks.feltHue}
          onChange={v => setTweak('feltHue', v)}
          options={[
            { value: 'purple', label: 'Royal purple' },
            { value: 'magenta', label: 'Magenta' },
            { value: 'teal', label: 'Deep teal' },
            { value: 'crimson', label: 'Crimson' },
          ]}
        />
        <TweakRadio
          label="Animation intensity"
          value={tweaks.animationIntensity}
          onChange={v => setTweak('animationIntensity', v)}
          options={[
            { value: 'subtle', label: 'Subtle' },
            { value: 'balanced', label: 'Balanced' },
            { value: 'heavy', label: 'Heavy' },
          ]}
        />
      </TweakSection>
      <TweakSection label="Layout">
        <TweakRadio
          label="Hand layout"
          value={tweaks.fanLayout}
          onChange={v => setTweak('fanLayout', v)}
          options={[
            { value: 'fanned', label: 'Fanned' },
            { value: 'stacked', label: 'Stacked' },
          ]}
        />
        <TweakRadio
          label="Compare style"
          value={tweaks.compareScreen}
          onChange={v => setTweak('compareScreen', v)}
          options={[
            { value: 'bars', label: 'Stat bars' },
            { value: 'cards', label: 'Cards only' },
          ]}
        />
      </TweakSection>
    </TweaksPanel>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
