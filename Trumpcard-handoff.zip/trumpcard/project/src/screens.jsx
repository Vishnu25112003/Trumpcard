/* All gameplay screens */

const { useState: useStateS, useEffect: useEffectS, useRef: useRefS, useMemo: useMemoS, useCallback: useCallbackS } = React;

// ============================================================
// TopBar — shared chrome
// ============================================================
function TopBar({ round, code, isYourTurn, timer }) {
  return (
    <div className="top-bar">
      <div className="brand">
        <div className="brand-mark">T</div>
        <div className="brand-text">
          <div className="b1">{code || 'TRUMPCARD'}</div>
          <div className="b2">{round ? `Round ${round}` : 'Anime Trumpcard'}</div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {timer != null && (
          <div className="round-pill">
            <span>⏱</span><span>{timer}s</span>
          </div>
        )}
        {isYourTurn != null && (
          <div className={`turn-pill ${isYourTurn ? '' : 'waiting'}`}>
            {isYourTurn ? 'YOUR TURN' : 'OPPONENT'}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Splash — name entry
// ============================================================
function SplashScreen({ onSubmit }) {
  const [name, setName] = useStateS('');
  // Three sample cards for the logo stack
  const sampleCards = useMemoS(() => {
    const deck = TC.buildDeck();
    return [deck[12], deck[0], deck[26]];
  }, []);

  return (
    <div className="center-screen">
      <div className="splash-logo">
        <div className="cards-stack">
          {sampleCards.map((c, i) => (
            <PlayingCard key={i} card={c} size="sm" faceUp={true} />
          ))}
        </div>
      </div>

      <h1 className="splash-title">Anime Trumpcard</h1>
      <div className="splash-sub">Battle with your favourite characters</div>

      <div className="stat-chips">
        {TC.STATS.map(s => (
          <div key={s.key} className="chip">
            <span style={{ color: s.color }}>{s.icon}</span>
            <span>{s.label}</span>
          </div>
        ))}
      </div>

      <div className="field-card">
        <div className="stack">
          <div>
            <label className="field-label">Player Name</label>
            <input
              className="field-input"
              placeholder="Enter your name…"
              value={name}
              onChange={e => setName(e.target.value)}
              maxLength={20}
              onKeyDown={(e) => { if (e.key === 'Enter' && name.trim()) onSubmit(name.trim()); }}
            />
          </div>
          <button
            className="btn btn-purple"
            disabled={!name.trim()}
            onClick={() => name.trim() && onSubmit(name.trim())}
            style={{ width: '100%' }}
          >
            Take a Seat →
          </button>
          <div className="muted center">
            No account · Up to 4 players · 52 cards
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Lobby — create or join
// ============================================================
function LobbyScreen({ name, onCreate, onJoin, onLeave }) {
  const [mode, setMode] = useStateS('create'); // 'create' | 'join'
  const [players, setPlayers] = useStateS(2);
  const [cards, setCards] = useStateS(10);
  const [joinCode, setJoinCode] = useStateS('');

  const cardOptions = [5, 8, 10, 13];

  return (
    <>
      <TopBar />
      <div className="center-screen">
        <h2 style={{
          fontFamily: 'var(--font-display)',
          fontSize: 32,
          margin: '0 0 4px',
          letterSpacing: '0.02em',
        }}>
          Welcome, <span style={{ color: 'var(--gold)' }}>{name}</span>
        </h2>
        <div className="muted" style={{ marginBottom: 22 }}>Create a table or join with a code</div>

        <div className="field-card">
          <div className="tab-switch">
            <button className={mode === 'create' ? 'active' : ''} onClick={() => setMode('create')}>+ Create Table</button>
            <button className={mode === 'join' ? 'active' : ''} onClick={() => setMode('join')}>→ Join Table</button>
          </div>

          {mode === 'create' ? (
            <div className="stack">
              <div>
                <label className="field-label">Number of Players</label>
                <div className="option-grid cols-3">
                  {[2, 3, 4].map(n => (
                    <button key={n} className={`opt ${players === n ? 'active' : ''}`} onClick={() => setPlayers(n)}>
                      {n} {n === 2 ? '· 1v1' : 'P'}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="field-label">Cards per Player</label>
                <div className="option-grid cols-5" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
                  {cardOptions.map(n => (
                    <button key={n} className={`opt ${cards === n ? 'active' : ''}`} onClick={() => setCards(n)}>{n}</button>
                  ))}
                </div>
                <div className="muted" style={{ marginTop: 6, fontSize: 11 }}>
                  {players * cards} / 52 cards used
                </div>
              </div>
              <button className="btn btn-purple" onClick={() => onCreate(players, cards)} style={{ width: '100%' }}>
                Deal the Table
              </button>
            </div>
          ) : (
            <div className="stack">
              <div>
                <label className="field-label">Room Code</label>
                <input
                  className="field-input code"
                  placeholder="ANIME-XXXX"
                  value={joinCode}
                  onChange={e => setJoinCode(e.target.value.toUpperCase())}
                  maxLength={10}
                />
              </div>
              <button
                className="btn btn-purple"
                onClick={() => onJoin(joinCode || 'ANIME-DEMO')}
                disabled={joinCode.length < 4}
                style={{ width: '100%' }}
              >
                Join Table →
              </button>
            </div>
          )}
        </div>

        <button className="btn btn-ghost btn-sm" style={{ marginTop: 18 }} onClick={onLeave}>← Change Name</button>
      </div>
    </>
  );
}

// ============================================================
// GameLobby — waiting for players
// ============================================================
function GameLobbyScreen({ name, code, numPlayers, cardsPerPlayer, onStart, onLeave }) {
  const [joined, setJoined] = useStateS(1);
  const [copied, setCopied] = useStateS(false);

  // Simulate other players joining
  useEffectS(() => {
    if (joined >= numPlayers) return;
    const t = setTimeout(() => setJoined(j => Math.min(numPlayers, j + 1)), 1800 + Math.random() * 1200);
    return () => clearTimeout(t);
  }, [joined, numPlayers]);

  // When full, auto-start
  useEffectS(() => {
    if (joined >= numPlayers) {
      const t = setTimeout(onStart, 1200);
      return () => clearTimeout(t);
    }
  }, [joined, numPlayers, onStart]);

  const otherNames = ['Akira', 'Yuki', 'Ren'];

  return (
    <>
      <TopBar />
      <div className="center-screen">
        <div className="code-display" onClick={() => {
          navigator.clipboard && navigator.clipboard.writeText(code);
          setCopied(true); setTimeout(() => setCopied(false), 1500);
        }} style={{ cursor: 'pointer' }}>
          <div className="label">Room Code</div>
          <div className="code">{code}</div>
          <div className="sub">{copied ? '✓ Copied to clipboard' : 'Tap to copy & share'}</div>
        </div>

        <div className="mini-stats">
          <div className="mini-stat">
            <div className="v">{numPlayers}</div>
            <div className="l">Players</div>
          </div>
          <div className="mini-stat">
            <div className="v">{cardsPerPlayer}</div>
            <div className="l">Cards Each</div>
          </div>
          <div className="mini-stat">
            <div className="v" style={{ color: joined >= numPlayers ? '#5ee08a' : 'var(--gold)' }}>
              {joined}/{numPlayers}
            </div>
            <div className="l">Joined</div>
          </div>
        </div>

        <div style={{ width: '100%', maxWidth: 420, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div className="field-label" style={{ marginBottom: 2 }}>Players at Table</div>
          <div className="player-row">
            <div className="player-avatar">{name[0]?.toUpperCase()}</div>
            <div className="name">{name} <span className="you">(you)</span></div>
            <div className="badge badge-host">Host</div>
          </div>
          {Array.from({ length: numPlayers - 1 }).map((_, i) => {
            const isJoined = joined > i + 1;
            const playerName = otherNames[i] || `Player ${i + 2}`;
            return (
              <div key={i} className={`player-row ${isJoined ? '' : 'waiting'}`}>
                <div className={`player-avatar p${i + 2} ${isJoined ? '' : 'empty'}`}>
                  {isJoined ? playerName[0] : '?'}
                </div>
                <div className="name">
                  {isJoined ? playerName : 'Waiting for player…'}
                </div>
                {!isJoined && <span style={{ fontSize: 18, animation: 'trophy-bob 1.2s infinite' }}>•••</span>}
              </div>
            );
          })}
        </div>

        <div style={{ marginTop: 22 }}>
          {joined >= numPlayers ? (
            <div style={{
              fontFamily: 'var(--font-display)',
              fontSize: 18,
              letterSpacing: '0.12em',
              color: 'var(--gold)',
              textShadow: '0 0 16px rgba(212,175,55,0.5)',
            }}>
              ✦ Shuffling the deck…
            </div>
          ) : (
            <div className="muted">Waiting for {numPlayers - joined} more player{numPlayers - joined === 1 ? '' : 's'}…</div>
          )}
        </div>

        <button className="btn btn-ghost btn-sm" style={{ marginTop: 22 }} onClick={onLeave}>Leave Table</button>
      </div>
    </>
  );
}

// ============================================================
// Game screen — top card, fan of hand, opponent
// ============================================================
function GameScreen({
  round, code, players, hands, currentPlayer, timer,
  onStatTap, comparison, onCompareDone, lastResult
}) {
  const youIdx = 0;
  const isYourTurn = currentPlayer === youIdx;
  const yourHand = hands[youIdx] || [];
  const yourTop = yourHand[0];

  return (
    <>
      <TopBar round={round} code={code} isYourTurn={isYourTurn} timer={timer} />

      <div className="game-stage">
        {/* Opponent's fan(s) at top */}
        <div style={{ display: 'flex', justifyContent: 'space-around', gap: 30, marginTop: 4, marginBottom: 4, flexShrink: 0 }}>
          {players.slice(1).map((p, idx) => {
            const handIdx = idx + 1;
            const hand = hands[handIdx] || [];
            return (
              <div key={handIdx} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
                <FanOfCards count={hand.length} size="sm" maxAngle={20} spacing={14} />
                <div style={{
                  fontSize: 10,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: currentPlayer === handIdx ? 'var(--gold)' : 'var(--text-dim)',
                  fontFamily: 'var(--font-display)',
                }}>
                  {p.name} · {hand.length}
                </div>
              </div>
            );
          })}
        </div>

        <div className="play-area">
          <div className="area-label">— Your Top Card —</div>

          {yourTop && (
            <PlayingCard
              card={yourTop}
              size="lg"
              faceUp={true}
              interactive={isYourTurn && !comparison}
              onStatTap={onStatTap}
              shine={isYourTurn && !comparison}
            />
          )}

          <div style={{
            fontFamily: 'var(--font-display)',
            fontSize: 13,
            letterSpacing: '0.14em',
            textTransform: 'uppercase',
            color: isYourTurn ? 'var(--gold)' : 'var(--text-dim)',
            marginTop: 6,
          }}>
            {isYourTurn ? '↑ Tap a stat to battle' : `Waiting for ${players[currentPlayer]?.name}…`}
          </div>

          {/* Your hand fan (extra cards behind top) */}
          {yourHand.length > 1 && (
            <div className="hand-fan">
              <FanOfCards count={yourHand.length - 1} size="sm" maxAngle={30} spacing={20} yArc={18} />
            </div>
          )}
        </div>

        {/* Bottom players bar — full status */}
        <div className="players-bar">
          {players.map((p, i) => (
            <div key={i} className={`player-tag p-${i + 1} ${currentPlayer === i ? 'is-turn' : ''}`}>
              <div className="pa">{p.name[0]}</div>
              <div className="info">
                <div className="n">{p.name}{i === youIdx ? ' (you)' : ''}</div>
                <div className="c">{currentPlayer === i ? 'choosing…' : 'waiting'}</div>
              </div>
              <div className="cards-count">
                <span>🃏</span>{hands[i]?.length || 0}
              </div>
            </div>
          ))}
        </div>
      </div>

      {comparison && (
        <ComparisonOverlay
          players={players}
          cards={comparison.cards}
          stat={comparison.stat}
          winnerIdx={comparison.winnerIdx}
          onDone={onCompareDone}
        />
      )}

      {lastResult && !comparison && (
        <RoundResultBanner
          players={players}
          result={lastResult}
        />
      )}
    </>
  );
}

// ============================================================
// ComparisonOverlay
// ============================================================
function ComparisonOverlay({ players, cards, stat, winnerIdx, onDone }) {
  const [stage, setStage] = useStateS(0);
  // 0: cards face-down sliding in
  // 1: flip
  // 2: bars filling
  // 3: winner revealed

  const statMeta = TC.STATS.find(s => s.key === stat) || TC.STATS[0];

  useEffectS(() => {
    const t1 = setTimeout(() => setStage(1), 600);   // flip cards
    const t2 = setTimeout(() => setStage(2), 1400);  // start bars
    const t3 = setTimeout(() => setStage(3), 2400);  // reveal winner
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  // For each player in compare (2 cards only — we compare turn taker vs nearest opponent)
  const [cL, cR] = cards;
  const [pL, pR] = [players[0], players[1]];
  const valL = cL[stat], valR = cR[stat];
  const max = Math.max(valL, valR, 1);
  const winL = winnerIdx === 0;
  const winR = winnerIdx === 1;

  return (
    <div className="compare-overlay">
      <div className="compare-arena">
        <div className="compare-stat-banner">
          <span>{statMeta.icon}</span>
          <span>{statMeta.label} decides!</span>
        </div>

        <div className="compare-vs-row">
          <div className={`compare-side left ${winL ? 'win' : ''}`}>
            <PlayingCard
              card={cL}
              size="md"
              faceUp={stage >= 1}
              winningStat={stage >= 3 && winL ? stat : null}
              losingStat={stage >= 3 && !winL ? stat : null}
            />
            <div className="compare-player-tag">{pL?.name || 'You'}</div>
          </div>

          <div className="vs-mark">VS</div>

          <div className={`compare-side right ${winR ? 'win' : ''}`}>
            <PlayingCard
              card={cR}
              size="md"
              faceUp={stage >= 1}
              winningStat={stage >= 3 && winR ? stat : null}
              losingStat={stage >= 3 && !winR ? stat : null}
            />
            <div className="compare-player-tag">{pR?.name || 'Opponent'}</div>
          </div>
        </div>

        <div className="compare-bars">
          <div className={`compare-bar ${winL ? 'win-l' : ''} ${winR ? 'win-r' : ''}`}>
            <div className="cv l">{stage >= 2 ? valL : '?'}</div>
            <div className="track">
              <div className="fill-l" style={{ width: stage >= 2 ? `${(valL / max) * 50}%` : '0%' }} />
              <div className="fill-r" style={{ width: stage >= 2 ? `${(valR / max) * 50}%` : '0%' }} />
            </div>
            <div className="cv r">{stage >= 2 ? valR : '?'}</div>
          </div>
        </div>

        {stage >= 3 && (
          <button className="btn btn-gold" style={{ marginTop: 16 }} onClick={onDone}>
            Next Round →
          </button>
        )}
      </div>

      {stage >= 3 && (
        <Particles active={true} type={winL ? 'gold' : 'confetti'} count={winL ? 80 : 40} />
      )}
    </div>
  );
}

// (kept exported but mostly unused — round result is shown inside comparison flow)
function RoundResultBanner({ players, result }) {
  return null;
}

// ============================================================
// GameOver
// ============================================================
function GameOverScreen({ players, winnerIdx, youIdx, onPlayAgain, onChangeName }) {
  const youWin = winnerIdx === youIdx;
  return (
    <>
      <TopBar />
      <div className="center-screen">
        <div className={`trophy ${youWin ? '' : 'lose'}`}>
          {youWin ? '🏆' : '🎴'}
        </div>
        <h1 style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(36px, 7vw, 58px)',
          margin: '12px 0 6px',
          color: youWin ? 'var(--gold-bright)' : 'var(--text)',
          textShadow: youWin ? '0 0 30px rgba(212,175,55,0.5)' : 'none',
        }}>
          {youWin ? 'You Win!' : 'Game Over'}
        </h1>
        <div style={{ fontSize: 16, color: 'var(--text-soft)', marginBottom: 28 }}>
          {youWin
            ? 'You collected all the cards.'
            : <><span style={{ color: 'var(--gold)' }}>{players[winnerIdx]?.name}</span> takes the table.</>
          }
        </div>

        {youWin && (
          <div style={{ fontSize: 28, marginBottom: 24, letterSpacing: '0.2em' }}>
            ⭐ ✨ 💫 ✨ ⭐
          </div>
        )}

        <div className="field-card" style={{ padding: 14 }}>
          <div className="field-label center">Result</div>
          <div style={{
            textAlign: 'center',
            fontFamily: 'var(--font-display)',
            fontSize: 22,
            color: youWin ? 'var(--gold-bright)' : 'var(--text)',
            padding: '6px 0',
          }}>
            🏅 {youWin ? 'Champion' : 'Runner-up'}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, marginTop: 22, width: '100%', maxWidth: 380 }}>
          <button className="btn btn-purple" style={{ flex: 1 }} onClick={onPlayAgain}>Play Again</button>
          <button className="btn btn-ghost" onClick={onChangeName}>Change Name</button>
        </div>
      </div>

      {youWin && <Particles active={true} type="gold" count={120} />}
    </>
  );
}

Object.assign(window, {
  TopBar, SplashScreen, LobbyScreen, GameLobbyScreen, GameScreen,
  ComparisonOverlay, GameOverScreen
});
