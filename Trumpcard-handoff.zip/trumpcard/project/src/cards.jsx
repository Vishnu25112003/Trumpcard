/* Card components — face, back, fan, particles */

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// SVG path for ornate filigree corner
function CornerDeco() {
  return (
    <svg viewBox="0 0 26 26" fill="none">
      <path d="M 2 10 Q 2 2 10 2 M 2 14 Q 2 6 6 4 M 4 18 Q 4 4 18 4 M 8 22 Q 4 8 22 8"
        stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" />
      <circle cx="10" cy="10" r="1.2" fill="currentColor" />
      <circle cx="6" cy="6" r="0.8" fill="currentColor" opacity="0.7" />
    </svg>
  );
}

// ============================================================
// PlayingCard — modern poker design
// ============================================================
function PlayingCard({
  card,
  size = 'md',                      // sm | md | lg | xl
  faceUp = true,
  interactive = false,
  selectedStat = null,
  winningStat = null,
  losingStat = null,
  onStatTap = null,
  shine = false,
  className = '',
  style = null,
  imageUrl = null,
}) {
  const glyph = TC.SUIT_GLYPH[card.suit];
  const photo = imageUrl || card.image || TC.portraitURL(card);

  // Split 6 stats: first 3 on left, last 3 on right
  const leftStats = TC.STATS.slice(0, 3);
  const rightStats = TC.STATS.slice(3, 6);

  function renderStat(stat) {
    let cls = '';
    if (interactive) cls += ' interactive';
    if (selectedStat === stat.key) cls += ' selected';
    if (winningStat === stat.key) cls += ' win';
    if (losingStat === stat.key) cls += ' lose';
    return (
      <div
        key={stat.key}
        className={`pc-stat${cls}`}
        style={{ color: stat.color }}
        onClick={(e) => {
          if (interactive && onStatTap) {
            e.stopPropagation();
            onStatTap(stat.key);
          }
        }}
      >
        <div className="pc-stat-icon">{stat.icon}</div>
        <div className="pc-stat-val">{card[stat.key]}</div>
        <div className="pc-stat-label">{stat.label}</div>
      </div>
    );
  }

  return (
    <div
      className={`pc size-${size} ${faceUp ? '' : 'flipped'} ${shine ? 'shine' : ''} ${className}`}
      style={style}
    >
      <div className="pc-face">
        {/* Gold filigree corners */}
        <div className="pc-corner-deco tl"><CornerDeco /></div>
        <div className="pc-corner-deco tr"><CornerDeco /></div>
        <div className="pc-corner-deco bl"><CornerDeco /></div>
        <div className="pc-corner-deco br"><CornerDeco /></div>

        {/* Sparkles */}
        <div className="pc-sparkles">
          <span /><span /><span /><span /><span />
        </div>

        {/* Big suit at top center */}
        <div className="pc-suit-top">{glyph}</div>

        {/* 3-col body: left stats | portrait | right stats */}
        <div className="pc-face-inner">
          <div className="pc-stat-col">{leftStats.map(renderStat)}</div>
          <div className="pc-portrait">
            <img src={photo} alt={card.name} draggable="false" />
          </div>
          <div className="pc-stat-col">{rightStats.map(renderStat)}</div>
        </div>

        {/* Name plate */}
        <div className="pc-name">{card.name}</div>
      </div>

      <CardBackArt />
    </div>
  );
}

// ============================================================
// CardBack
// ============================================================
function CardBack({ size = 'md', className = '', style = null }) {
  return (
    <div className={`pc size-${size} flipped ${className}`} style={style}>
      <div className="pc-face" />
      <CardBackArt />
    </div>
  );
}

function CardBackArt() {
  return (
    <div className="pc-back">
      <div className="pc-back-art">
        <div className="pc-back-frame" />
        <div className="pc-corner-deco tl" style={{ zIndex: 4 }}><CornerDeco /></div>
        <div className="pc-corner-deco tr" style={{ zIndex: 4 }}><CornerDeco /></div>
        <div className="pc-corner-deco bl" style={{ zIndex: 4 }}><CornerDeco /></div>
        <div className="pc-corner-deco br" style={{ zIndex: 4 }}><CornerDeco /></div>
        <div className="pc-back-emblem">
          <div className="ring">
            <div className="glyph">T</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// FanOfCards
// ============================================================
function FanOfCards({
  count = 5,
  size = 'sm',
  maxAngle = 28,
  spacing = 18,
  yArc = 16,
  className = '',
}) {
  const visible = Math.min(count, 9);
  const hidden = count - visible;

  const cards = useMemo(() => {
    if (visible <= 1) return [{ angle: 0, x: 0, y: 0 }];
    const step = maxAngle / (visible - 1);
    return Array.from({ length: visible }, (_, i) => {
      const t = i - (visible - 1) / 2;
      const angle = t * step;
      const x = t * spacing;
      const norm = t / ((visible - 1) / 2 || 1);
      const y = (norm * norm) * yArc;
      return { angle, x, y };
    });
  }, [visible, maxAngle, spacing, yArc]);

  return (
    <div className={`fan ${className}`}>
      {cards.map((c, i) => (
        <div
          key={i}
          className="fan-card"
          style={{
            transform: `translate(${c.x}px, ${c.y}px) rotate(${c.angle}deg)`,
            zIndex: i,
          }}
        >
          <CardBack size={size} />
        </div>
      ))}
      {hidden > 0 && (
        <div
          style={{
            position: 'absolute',
            bottom: -6,
            right: '46%',
            transform: 'translateX(50%)',
            background: 'rgba(0,0,0,0.65)',
            border: '1px solid var(--line-gold)',
            color: 'var(--gold)',
            padding: '2px 8px',
            borderRadius: 8,
            fontSize: 10,
            fontFamily: 'var(--font-mono)',
            letterSpacing: '0.08em',
            fontWeight: 700,
          }}
        >
          +{hidden}
        </div>
      )}
    </div>
  );
}

// ============================================================
// Particles
// ============================================================
function Particles({ active, type = 'confetti', count = 60, onDone }) {
  const [parts, setParts] = useState([]);

  useEffect(() => {
    if (!active) return;
    const colors = type === 'gold'
      ? ['#ffe585', '#f0c750', '#b8881e', '#fffac8']
      : ['#f0c750', '#9a5cff', '#ff5d9e', '#5eecff', '#5ee08a', '#fff'];

    const list = Array.from({ length: count }, (_, i) => ({
      id: i,
      x: 50 + (Math.random() - 0.5) * 30,
      y: 50 + (Math.random() - 0.5) * 10,
      vx: (Math.random() - 0.5) * 200,
      vy: -300 - Math.random() * 250,
      rot: Math.random() * 360,
      vr: (Math.random() - 0.5) * 720,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: 4 + Math.random() * 8,
      shape: Math.random() < 0.3 ? 'circle' : 'square',
      life: 0,
    }));
    setParts(list);

    const start = performance.now();
    let raf;
    function tick(t) {
      const dt = (t - start) / 1000;
      setParts(prev => prev.map(p => ({ ...p, life: dt })));
      if (dt < 3) raf = requestAnimationFrame(tick);
      else { setParts([]); onDone && onDone(); }
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, type, count]);

  if (!parts.length) return null;

  return (
    <div className="particles">
      {parts.map(p => {
        const dx = p.vx * p.life;
        const dy = p.vy * p.life + 0.5 * 600 * p.life * p.life;
        const r = p.rot + p.vr * p.life;
        const opacity = Math.max(0, 1 - p.life / 3);
        return (
          <div
            key={p.id}
            className="particle"
            style={{
              left: `calc(${p.x}% + ${dx}px)`,
              top: `calc(${p.y}% + ${dy}px)`,
              width: p.size,
              height: p.size,
              background: p.color,
              borderRadius: p.shape === 'circle' ? '50%' : '2px',
              transform: `rotate(${r}deg)`,
              opacity,
              boxShadow: `0 0 ${p.size * 1.5}px ${p.color}aa`,
            }}
          />
        );
      })}
    </div>
  );
}

// ============================================================
// Floating sparkles layer (used on background)
// ============================================================
function SparkleLayer({ count = 24 }) {
  const sparkles = useMemo(() => Array.from({ length: count }, () => ({
    left: Math.random() * 100,
    delay: Math.random() * 8,
    duration: 6 + Math.random() * 4,
    size: 2 + Math.random() * 4,
  })), [count]);

  return (
    <div className="sparkle-layer">
      {sparkles.map((s, i) => (
        <div
          key={i}
          className="sparkle"
          style={{
            left: `${s.left}%`,
            bottom: '-20px',
            width: s.size,
            height: s.size,
            animationDelay: `${s.delay}s`,
            animationDuration: `${s.duration}s`,
          }}
        />
      ))}
    </div>
  );
}

Object.assign(window, {
  PlayingCard, CardBack, CardBackArt, FanOfCards, Particles, SparkleLayer
});
