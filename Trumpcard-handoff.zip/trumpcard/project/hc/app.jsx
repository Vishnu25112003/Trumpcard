/* Hand Cricket UI preview — a playable mini match vs CPU that exercises every
   upgraded screen, plus a "jump to scene" panel so each detail can be inspected.
   This is a visual preview of the UI upgrades; the real game keeps its server logic. */

const { useState, useEffect, useRef, useCallback } = React;

const MAX_BALLS = 6;
const START_LIVES = 3;
const emptyScore = () => ({ runs: 0, balls: 0, wickets: 0 });
const rnd = () => 1 + Math.floor(Math.random() * 6);

function App() {
  const [phase, setPhase] = useState('toss');        // toss | innings-start | picking | revealing | break | ended
  const [innings, setInnings] = useState(1);
  const [battingRole, setBattingRole] = useState('me');
  const [scores, setScores] = useState({ me: emptyScore(), cpu: emptyScore() });
  const [lives, setLives] = useState({ me: START_LIVES, cpu: START_LIVES });
  const [target, setTarget] = useState(null);
  const [myPick, setMyPick] = useState(null);
  const [timer, setTimer] = useState(7);
  const [reveal, setReveal] = useState(null);
  const [notif, setNotif] = useState(null);
  const [bannerMsg, setBannerMsg] = useState('');
  const [won, setWon] = useState(false);
  const [endReason, setEndReason] = useState('');
  const [frozen, setFrozen] = useState(false);        // scene-inspect mode

  const pending = useRef(null);
  const timerRef = useRef(null);

  const isBatting = battingRole === 'me';
  const myName = 'You', cpuName = 'Vishnu';

  const showNotif = useCallback((msg, color = 'var(--cyan)') => {
    setNotif({ msg, color });
    setTimeout(() => setNotif(n => (n && n.msg === msg ? null : n)), 3000);
  }, []);

  // ---- timer ----
  useEffect(() => {
    if (phase !== 'picking' || frozen || myPick != null) { clearInterval(timerRef.current); return; }
    setTimer(7);
    const end = Date.now() + 7000;
    timerRef.current = setInterval(() => {
      const r = Math.max(0, Math.ceil((end - Date.now()) / 1000));
      setTimer(r);
      if (r <= 0) { clearInterval(timerRef.current); resolveBall(rnd()); }
    }, 250);
    return () => clearInterval(timerRef.current);
    // eslint-disable-next-line
  }, [phase, myPick, frozen, innings, battingRole]);

  // ---- auto-advance after reveal ----
  useEffect(() => {
    if (phase !== 'revealing' || frozen) return;
    const t = setTimeout(advanceAfterReveal, 2400);
    return () => clearTimeout(t);
    // eslint-disable-next-line
  }, [phase, frozen]);

  function startInnings(role, inns, tgt) {
    setBattingRole(role);
    setInnings(inns);
    setTarget(tgt);
    setMyPick(null);
    setReveal(null);
    setBannerMsg(`Innings ${inns} — ${role === 'me' ? 'You' : cpuName} bats`);
    setPhase('innings-start');
    setTimeout(() => setPhase('picking'), 1900);
  }

  function onTossChoose(choice) {
    // choosing bat => you bat innings 1; bowl => cpu bats
    const role = choice === 'bat' ? 'me' : 'cpu';
    setScores({ me: emptyScore(), cpu: emptyScore() });
    setLives({ me: START_LIVES, cpu: START_LIVES });
    startInnings(role, 1, null);
  }

  function resolveBall(myVal) {
    clearInterval(timerRef.current);
    const cpuVal = rnd();
    const batRole = battingRole;
    const bowlRole = batRole === 'me' ? 'cpu' : 'me';
    const batPick = batRole === 'me' ? myVal : cpuVal;
    const bowlPick = batRole === 'me' ? cpuVal : myVal;
    const isWicket = batPick === bowlPick;
    const runs = isWicket ? 0 : batPick;

    const newScores = { me: { ...scores.me }, cpu: { ...scores.cpu } };
    newScores[batRole].balls += 1;
    if (isWicket) newScores[batRole].wickets += 1;
    else newScores[batRole].runs += runs;

    const newLives = { ...lives };
    if (isWicket) {
      newLives[batRole] = Math.max(0, newLives[batRole] - 1);
      const who = batRole === 'me' ? 'You' : cpuName;
      showNotif(`${who} lost a life (${newLives[batRole]} left)`, 'var(--red)');
    }

    setScores(newScores);
    setLives(newLives);
    setReveal({ myThrow: myVal, oppThrow: cpuVal, batPick, bowlPick, runs, isWicket, batRole, batsmanName: batRole === 'me' ? 'You' : cpuName, bowlerName: bowlRole === 'me' ? 'You' : cpuName });

    // figure out what happens next
    const inningsOver = newLives[batRole] <= 0 || newScores[batRole].balls >= MAX_BALLS;
    const chaseDone = innings === 2 && target != null && newScores[batRole].runs >= target;
    pending.current = { inningsOver, chaseDone, newScores, batRole };
    setPhase('revealing');
  }

  function advanceAfterReveal() {
    const p = pending.current;
    if (!p) { setPhase('picking'); return; }
    const { inningsOver, chaseDone, newScores, batRole } = p;

    if (innings === 2 && (chaseDone || inningsOver)) {
      // match end
      const meWin = newScores.me.runs > newScores.cpu.runs
        ? true
        : newScores.me.runs < newScores.cpu.runs ? false
        : battingRole === 'me'; // tie edge → batsman edge
      setWon(meWin);
      setEndReason(chaseDone ? '🎯 Target Crossed' : '✅ Match Complete');
      setPhase('ended');
      return;
    }

    if (innings === 1 && inningsOver) {
      const tgt = newScores[batRole].runs + 1;
      setTarget(tgt);
      setPhase('break');
      return;
    }

    // next ball
    setMyPick(null);
    setReveal(null);
    setPhase('picking');
  }

  function onPick(n) {
    if (myPick != null || phase !== 'picking') return;
    setMyPick(n);
    setTimeout(() => resolveBall(n), 420); // small beat after your throw
  }

  function startInnings2() {
    const newBat = battingRole === 'me' ? 'cpu' : 'me';
    startInnings(newBat, 2, target);
  }

  function restart() {
    setFrozen(false);
    setScores({ me: emptyScore(), cpu: emptyScore() });
    setLives({ me: START_LIVES, cpu: START_LIVES });
    setTarget(null); setMyPick(null); setReveal(null);
    setInnings(1); setBattingRole('me');
    setPhase('toss');
  }

  // ---- scene jumper (inspect individual upgraded states) ----
  function scene(name) {
    clearInterval(timerRef.current);
    setFrozen(true);
    setNotif(null);
    if (name === 'toss') { setFrozen(false); setPhase('toss'); return; }
    if (name === 'pick') {
      setFrozen(false);
      setScores({ me: { runs: 7, balls: 2, wickets: 0 }, cpu: emptyScore() });
      setLives({ me: 3, cpu: 3 }); setBattingRole('me'); setInnings(1);
      setTarget(null); setMyPick(null); setPhase('picking'); return;
    }
    setScores({ me: { runs: 7, balls: 3, wickets: 0 }, cpu: { runs: 0, balls: 0, wickets: 0 } });
    setLives({ me: 3, cpu: 3 }); setBattingRole('me'); setInnings(1); setTarget(null);
    const map = {
      runs: { myThrow: 4, oppThrow: 2, runs: 4, isWicket: false, batRole: 'me' },
      out:  { myThrow: 6, oppThrow: 6, runs: 0, isWicket: true, batRole: 'me' },
    };
    if (map[name]) { setReveal({ ...map[name], batsmanName: 'You', bowlerName: cpuName }); setPhase('revealing'); return; }
    if (name === 'pick') { setMyPick(null); setPhase('picking'); return; }
    if (name === 'break') { setTarget(8); setBattingRole('me'); setScores({ me: { runs: 7, balls: 6, wickets: 1 }, cpu: emptyScore() }); setPhase('break'); return; }
    if (name === 'win')  { setWon(true);  setEndReason('🎯 Target Crossed'); setScores({ me: { runs: 9, balls: 5, wickets: 0 }, cpu: { runs: 7, balls: 6, wickets: 1 } }); setPhase('ended'); return; }
    if (name === 'lose') { setWon(false); setEndReason('💀 Lives Exhausted'); setScores({ me: { runs: 4, balls: 6, wickets: 1 }, cpu: { runs: 7, balls: 5, wickets: 0 } }); setPhase('ended'); return; }
  }

  const modeLabel = `${MAX_BALLS}b · ${START_LIVES}W`;
  const needMore = target != null ? Math.max(0, target - (isBatting ? scores.me.runs : scores.cpu.runs)) : null;
  const myTone = isBatting ? 'gold' : 'purple';
  const oppTone = isBatting ? 'purple' : 'gold';

  return (
    <>
      <div className="table-bg" />
      <SideHandDefs />

      {notif && (
        <div style={{
          position: 'fixed', top: 78, left: '50%', transform: 'translateX(-50%)', zIndex: 99,
          padding: '10px 22px', background: 'var(--surface-strong)', border: `1px solid ${notif.color}`,
          borderRadius: 12, color: notif.color, fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 600,
          letterSpacing: '0.08em', boxShadow: '0 8px 24px rgba(0,0,0,0.5)', animation: 'hcFadeUp 0.25s ease',
        }}>{notif.msg}</div>
      )}

      <HCTopBar modeLabel={modeLabel} phaseRole={['picking', 'revealing'].includes(phase) ? (isBatting ? 'bat' : 'bowl') : null} onLeave={restart} />

      <div style={{ position: 'relative', zIndex: 10, height: '100%', display: 'flex', flexDirection: 'column', paddingTop: 76, paddingBottom: 16, overflowY: 'auto' }}>

        {phase === 'toss' && (
          <Center>
            <div style={{ fontSize: 11, letterSpacing: '0.26em', color: 'var(--cyan)', textTransform: 'uppercase', marginBottom: 4, fontWeight: 600 }}>Coin Toss</div>
            <Coin winnerName="You" isChooser onChoose={onTossChoose} />
          </Center>
        )}

        {phase === 'innings-start' && (
          <Center>
            <div style={{ fontFamily: 'var(--font-brand)', fontSize: 'clamp(22px,6vw,38px)', background: 'linear-gradient(180deg,var(--gold-bright),var(--gold-deep))', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent', textAlign: 'center', animation: 'hcBannerIn 0.4s ease' }}>{bannerMsg}</div>
          </Center>
        )}

        {['picking', 'revealing'].includes(phase) && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: '4px 12px 0', flex: 1, minHeight: 0 }}>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', alignItems: 'flex-start', flexWrap: 'wrap' }}>
              <ScorePanel name={myName} score={scores.me} lives={lives.me} isBatting={isBatting} isMe accent="var(--purple-bright)" flash={phase === 'revealing' && reveal && reveal.isWicket && reveal.batRole === 'me'} />
              {target != null && (
                <div style={{ alignSelf: 'center', padding: '8px 18px', borderRadius: 99, background: 'rgba(94,236,255,0.1)', border: '1px solid rgba(94,236,255,0.3)', fontSize: 12, color: 'var(--cyan)', fontFamily: 'var(--font-mono)', textAlign: 'center' }}>
                  Target {target}<br />Need {needMore}
                </div>
              )}
              <ScorePanel name={cpuName} score={scores.cpu} lives={lives.cpu} isBatting={!isBatting} isMe={false} accent="var(--pink)" flash={phase === 'revealing' && reveal && reveal.isWicket && reveal.batRole === 'cpu'} />
            </div>

            <PitchHands
              myValue={phase === 'revealing' && reveal ? reveal.myThrow : (myPick || 0)}
              oppValue={phase === 'revealing' && reveal ? reveal.oppThrow : 0}
              myTone={myTone} oppTone={oppTone}
              reveal={phase === 'revealing'}
              waitingMe={phase === 'picking' && myPick == null}
              waitingOpp={phase === 'picking'}
              center={
                phase === 'revealing' && reveal
                  ? <CenterReveal kind={reveal.isWicket ? 'out' : 'runs'} runs={reveal.runs} />
                  : <CenterReveal kind="status" text={myPick != null ? 'Waiting for opponent…' : isBatting ? 'You are batting' : 'You are bowling'} />
              }
            />

            <div style={{ paddingBottom: 8 }}>
              <NumberStrip onPick={onPick} picked={myPick} timer={timer} disabled={phase === 'revealing'} />
            </div>
          </div>
        )}

        {phase === 'break' && (
          <InningsBreak target={target} myRuns={scores.me.runs} oppRuns={scores.cpu.runs} myBalls={scores.me.balls} oppBalls={scores.cpu.balls} chasing={battingRole === 'me' ? false : true} onContinue={startInnings2} />
        )}

        {phase === 'ended' && (
          <GameOver won={won} myName={myName} oppName={cpuName} myScore={scores.me} oppScore={scores.cpu} reason={endReason} onRematch={restart} onExit={restart} />
        )}
      </div>

      <SceneBar onScene={scene} active={phase} />
    </>
  );
}

function Center({ children }) {
  return <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20, padding: '20px 24px', textAlign: 'center' }}>{children}</div>;
}

function SceneBar({ onScene }) {
  const [open, setOpen] = useState(false);
  const scenes = [
    ['toss', 'Toss'], ['pick', 'Pick'], ['runs', 'Runs'],
    ['out', 'OUT'], ['break', 'Break'], ['win', 'You win'], ['lose', 'You lose'],
  ];
  return (
    <div style={{ position: 'fixed', left: 14, bottom: 14, zIndex: 120, fontFamily: 'var(--font-body)' }}>
      <button onClick={() => setOpen(o => !o)} style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px', borderRadius: 10,
        background: 'var(--surface-strong)', border: '1px solid var(--line-strong)', color: 'var(--purple-soft)',
        fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 600, backdropFilter: 'blur(8px)',
      }}>
        ▦ Preview scenes {open ? '▾' : '▸'}
      </button>
      {open && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, maxWidth: 260, marginTop: 8 }}>
          {scenes.map(([k, label]) => (
            <button key={k} onClick={() => onScene(k)} style={{
              padding: '6px 11px', borderRadius: 8, background: 'var(--surface)', border: '1px solid var(--line)',
              color: 'var(--text-soft)', fontSize: 11, letterSpacing: '0.04em', backdropFilter: 'blur(8px)',
            }}>{label}</button>
          ))}
        </div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
