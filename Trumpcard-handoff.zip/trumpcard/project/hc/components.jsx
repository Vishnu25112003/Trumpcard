/* Upgraded Hand Cricket UI — hand-cricket.in style layout.
   Two big side hands (you = left, opponent = right) that open from a fist to the
   played number; plain 1–6 buttons at the bottom; a big center number reveal.
   Built on the deck's existing tokens — chrome/colours unchanged. */

const { useState: useStateC, useEffect: useEffectC, useRef: useRefC } = React;

const NUM_WORDS = { 1: 'ONE', 2: 'TWO', 3: 'THREE', 4: 'FOUR', 5: 'FIVE', 6: 'SIX' };

/* ---------- Top bar ---------- */
function HCTopBar({ modeLabel, phaseRole, onLeave }) {
  return (
    <div className="top-bar">
      <div className="brand">
        <div className="brand-mark" style={{ background: 'linear-gradient(135deg, var(--cyan), #2aa0c2)', color: '#0a3a4a' }}>🏏</div>
        <div className="brand-text">
          <div className="b1">{modeLabel}</div>
          <div className="b2" style={{ background: 'linear-gradient(180deg, var(--cyan), #2aa0c2)', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Hand Cricket</div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {phaseRole && <div className="round-pill">{phaseRole === 'bat' ? '🏏 Batting' : '⚾ Bowling'}</div>}
        <button className="btn btn-ghost btn-sm" onClick={onLeave} style={{ color: 'var(--text-dim)', fontSize: 11 }}>Leave</button>
      </div>
    </div>
  );
}

/* ---------- Score panel ---------- */
function ScorePanel({ name, score, lives, isBatting, isMe, accent = 'var(--purple-bright)', flash }) {
  return (
    <div style={{
      background: 'var(--surface-strong)',
      border: `1px solid ${flash ? 'var(--red)' : isBatting ? accent : 'var(--line)'}`,
      borderRadius: 16, padding: '12px 16px', minWidth: 118,
      boxShadow: flash ? '0 0 22px rgba(255,77,109,0.5)' : isBatting ? `0 0 18px ${accent}55` : 'none',
      transition: 'all 0.25s',
    }}>
      <div style={{ fontSize: 10, letterSpacing: '0.16em', color: isBatting ? accent : 'var(--text-dim)', textTransform: 'uppercase', marginBottom: 5, fontWeight: 600 }}>
        {isMe ? 'You' : name} {isBatting ? '🏏' : '⚾'}
      </div>
      <div style={{ fontFamily: 'var(--font-brand)', fontSize: 28, fontWeight: 700, color: 'var(--gold)', lineHeight: 1 }}>{score.runs}</div>
      <div style={{ fontSize: 11, color: 'var(--text-dim)', marginTop: 2 }}>{score.balls} balls · {score.wickets}W</div>
      {lives != null && (
        <div style={{ display: 'flex', gap: 4, marginTop: 7 }}>
          {[1, 2, 3].map(i => (
            <div key={i} style={{ width: 9, height: 9, borderRadius: '50%', background: i <= lives ? 'var(--green)' : 'rgba(0,0,0,0.4)', border: `1px solid ${i <= lives ? 'var(--green)' : 'var(--line)'}`, boxShadow: i <= lives ? '0 0 6px var(--green)' : 'none', transition: 'all 0.3s' }} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- The pitch: two big side hands + center reveal ---------- */
function PitchHands({ myValue, oppValue, myTone, oppTone, reveal, waitingMe, waitingOpp, center }) {
  return (
    <div className="hc-pitch">
      <div className="hc-hand-slot left">
        <SideHand value={myValue} side="left" tone={myTone} size={172} active={waitingMe && !reveal} reveal={reveal} />
        <div className="hc-hand-tag" style={{ color: myTone === 'gold' ? 'var(--gold)' : 'var(--purple-soft)' }}>You</div>
      </div>

      <div className="hc-center">{center}</div>

      <div className="hc-hand-slot right">
        <SideHand value={oppValue} side="right" tone={oppTone} size={172} active={waitingOpp && !reveal} reveal={reveal} />
        <div className="hc-hand-tag" style={{ color: oppTone === 'gold' ? 'var(--gold)' : 'var(--purple-soft)' }}>Opponent</div>
      </div>
    </div>
  );
}

/* big center number / OUT / status */
function CenterReveal({ kind, runs, text }) {
  if (kind === 'out') {
    return (
      <div className="hc-center-pop">
        <div className="hc-shock" />
        <div className="hc-big-out">OUT!</div>
      </div>
    );
  }
  if (kind === 'runs') {
    return (
      <div className="hc-center-pop">
        <div className="hc-big-num">{runs}</div>
        <div className="hc-big-word">{NUM_WORDS[runs] ? `${NUM_WORDS[runs]} !!!` : `+${runs}`}</div>
      </div>
    );
  }
  if (kind === 'miss') {
    return <div className="hc-center-pop"><div className="hc-big-word" style={{ color: 'var(--text-soft)' }}>{text}</div></div>;
  }
  if (kind === 'status') {
    return <div className="hc-center-status">{text}</div>;
  }
  return null;
}

/* ---------- Number strip (plain 1–6) ---------- */
function NumberStrip({ onPick, picked, disabled, timer }) {
  const urgent = timer <= 3 && picked == null;
  return (
    <div className="hc-numstrip">
      <div className="hc-timerbar">
        <div className="hc-timerbar-fill" style={{ width: `${(timer / 7) * 100}%`, background: urgent ? 'linear-gradient(90deg,var(--red),#ff8c69)' : 'linear-gradient(90deg,var(--cyan),var(--purple-bright))', boxShadow: urgent ? '0 0 10px var(--red)' : '0 0 10px var(--cyan)' }} />
      </div>
      <div className="hc-numrow">
        {[1, 2, 3, 4, 5, 6].map(n => {
          const isSel = picked === n;
          const isDis = disabled || picked != null;
          return (
            <button key={n} disabled={isDis}
              className={`hc-numbtn ${isSel ? 'sel' : ''} ${isDis && !isSel ? 'dim' : ''}`}
              onClick={() => !isDis && onPick(n)}>{n}</button>
          );
        })}
      </div>
    </div>
  );
}

/* ---------- Innings break ---------- */
function InningsBreak({ target, myRuns, oppRuns, myBalls, oppBalls, chasing, onContinue }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18, padding: '20px 24px', textAlign: 'center', maxWidth: 380, margin: '0 auto' }}>
      <div style={{ fontSize: 10, letterSpacing: '0.26em', textTransform: 'uppercase', color: 'var(--cyan)', fontWeight: 600 }}>Innings Break</div>
      <div style={{ fontFamily: 'var(--font-brand)', fontSize: 'clamp(26px,6vw,40px)', background: 'linear-gradient(180deg, var(--gold-bright), var(--gold-deep))', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent', lineHeight: 1 }}>Innings 1 Over</div>
      <div style={{ width: '100%', background: 'var(--surface-strong)', border: '1px solid var(--line-gold)', borderRadius: 16, padding: '18px 20px' }}>
        <div style={{ fontSize: 12, color: 'var(--text-dim)', marginBottom: 12, letterSpacing: '0.1em' }}>Final Score</div>
        <div style={{ display: 'flex', justifyContent: 'space-around' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 4 }}>You 🏏</div>
            <div style={{ fontFamily: 'var(--font-brand)', fontSize: 30, color: 'var(--gold)', lineHeight: 1 }}>{myRuns}</div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>{myBalls}b</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 4 }}>Opponent ⚾</div>
            <div style={{ fontFamily: 'var(--font-brand)', fontSize: 30, color: 'var(--gold)', lineHeight: 1 }}>{oppRuns}</div>
            <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>{oppBalls}b</div>
          </div>
        </div>
      </div>
      <div style={{ padding: '14px 28px', background: 'rgba(94,236,255,0.1)', border: '1px solid rgba(94,236,255,0.3)', borderRadius: 12 }}>
        <div style={{ fontSize: 10, color: 'var(--cyan)', letterSpacing: '0.2em', textTransform: 'uppercase', marginBottom: 4 }}>Target</div>
        <div style={{ fontFamily: 'var(--font-brand)', fontSize: 36, color: 'var(--cyan)', lineHeight: 1 }}>{target}</div>
        <div style={{ fontSize: 11, color: 'var(--text-soft)', marginTop: 4 }}>{chasing ? 'You need to chase' : 'Opponent needs to chase'}</div>
      </div>
      <button className="btn btn-gold" style={{ width: '100%', fontSize: 13 }} onClick={onContinue}>Start Innings 2 →</button>
    </div>
  );
}

/* ---------- Game over ---------- */
function GameOver({ won, myName, oppName, myScore, oppScore, reason, onRematch, onExit }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, padding: '20px 24px', textAlign: 'center' }}>
      {won && <HCConfetti />}
      <div className={`trophy${won ? '' : ' lose'}`} style={{ fontSize: 76, filter: `drop-shadow(0 0 30px ${won ? 'rgba(240,199,80,0.7)' : 'rgba(255,77,109,0.5)'})` }}>{won ? '🏆' : '😔'}</div>
      <div style={{ fontFamily: 'var(--font-brand)', fontSize: 'clamp(24px,6vw,42px)', background: won ? 'linear-gradient(180deg, var(--gold-bright), var(--gold-deep))' : 'linear-gradient(180deg, var(--text), var(--text-dim))', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{won ? 'You Win!' : 'You Lose'}</div>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
        <ScorePanel name={myName} score={myScore} isMe accent="var(--purple-bright)" />
        <ScorePanel name={oppName} score={oppScore} isMe={false} accent="var(--pink)" />
      </div>
      <div style={{ fontSize: 12, color: 'var(--text-dim)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>{reason || '✅ Match Complete'}</div>
      <div style={{ display: 'flex', gap: 12, marginTop: 4 }}>
        <button className="btn btn-gold" style={{ fontSize: 13, padding: '13px 28px' }} onClick={onRematch}>Rematch ↩</button>
        <button className="btn btn-ghost" style={{ fontSize: 13, padding: '13px 24px' }} onClick={onExit}>Exit</button>
      </div>
    </div>
  );
}

function HCConfetti() {
  const colors = ['#f0c750', '#9a5cff', '#ff5d9e', '#5eecff', '#5ee08a'];
  return (
    <div className="particles">
      {Array.from({ length: 70 }, (_, i) => i).map(i => (
        <div key={i} className="particle" style={{ left: `${Math.random() * 100}%`, top: '-12px', background: colors[i % colors.length], animation: `hcConfetti ${2.4 + Math.random() * 2}s linear ${Math.random() * 2.2}s infinite`, transform: `rotate(${Math.random() * 360}deg)` }} />
      ))}
    </div>
  );
}

Object.assign(window, { HCTopBar, ScorePanel, PitchHands, CenterReveal, NumberStrip, InningsBreak, GameOver, HCConfetti, NUM_WORDS });
