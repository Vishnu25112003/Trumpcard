/* Anime Trumpcard — data + helpers */
(function () {
  const SUITS = ['spade', 'heart', 'diamond', 'club'];
  const SUIT_GLYPH = { spade: '♠', heart: '♥', diamond: '♦', club: '♣' };
  const SUIT_RED = { heart: true, diamond: true };
  const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

  // Stat config — 6 stats matching screenshots
  const STATS = [
    { key: 'power',        label: 'Power',       icon: '💥', color: '#ff7e36' },
    { key: 'strength',     label: 'Strength',    icon: '💪', color: '#f0d564' },
    { key: 'speed',        label: 'Speed',       icon: '⚡', color: '#ffd23f' },
    { key: 'defense',      label: 'Defense',     icon: '🛡',  color: '#5ee08a' },
    { key: 'intelligence', label: 'Intel',       icon: '🧠', color: '#7ab8ff' },
    { key: 'popularity',   label: 'Pop',         icon: '⭐', color: '#ff5d9e' },
  ];

  // Curated Naruto-leaning anime roster (matches your existing data feel)
  const CHARACTERS = [
    { name: 'Naruto Uzumaki',   power: 95, strength: 85, speed: 92, defense: 80, intelligence: 70, popularity: 99, color: '#ff8a3d' },
    { name: 'Sasuke Uchiha',    power: 94, strength: 84, speed: 95, defense: 78, intelligence: 88, popularity: 97, color: '#5b4f8a' },
    { name: 'Sakura Haruno',    power: 78, strength: 88, speed: 75, defense: 70, intelligence: 85, popularity: 84, color: '#ff7eb6' },
    { name: 'Kakashi Hatake',   power: 90, strength: 80, speed: 88, defense: 82, intelligence: 96, popularity: 95, color: '#b0b0c4' },
    { name: 'Itachi Uchiha',    power: 96, strength: 78, speed: 93, defense: 75, intelligence: 99, popularity: 98, color: '#3a2a4a' },
    { name: 'Madara Uchiha',    power: 99, strength: 92, speed: 90, defense: 90, intelligence: 95, popularity: 92, color: '#6b2c4a' },
    { name: 'Hiruzen Sarutobi', power: 90, strength: 78, speed: 80, defense: 85, intelligence: 95, popularity: 82, color: '#8a6a3a' },
    { name: 'Jiraiya',          power: 88, strength: 85, speed: 80, defense: 84, intelligence: 90, popularity: 95, color: '#d24a4a' },
    { name: 'Tsunade',          power: 92, strength: 96, speed: 78, defense: 90, intelligence: 87, popularity: 88, color: '#d4af37' },
    { name: 'Orochimaru',       power: 91, strength: 78, speed: 85, defense: 80, intelligence: 97, popularity: 80, color: '#6e8f6a' },
    { name: 'Gaara',            power: 89, strength: 75, speed: 82, defense: 96, intelligence: 86, popularity: 91, color: '#c45a3a' },
    { name: 'Rock Lee',         power: 78, strength: 88, speed: 96, defense: 72, intelligence: 65, popularity: 82, color: '#3a8a5a' },
    { name: 'Neji Hyuga',       power: 84, strength: 80, speed: 88, defense: 82, intelligence: 90, popularity: 80, color: '#9aa8b8' },
    { name: 'Hinata Hyuga',     power: 76, strength: 70, speed: 80, defense: 75, intelligence: 82, popularity: 90, color: '#7a8aaa' },
    { name: 'Shikamaru Nara',   power: 70, strength: 65, speed: 72, defense: 70, intelligence: 99, popularity: 86, color: '#5a6a4a' },
    { name: 'Sasori',           power: 87, strength: 78, speed: 75, defense: 82, intelligence: 94, popularity: 78, color: '#c4423a' },
    { name: 'Deidara',          power: 86, strength: 76, speed: 84, defense: 70, intelligence: 88, popularity: 79, color: '#dfb84a' },
    { name: 'Pain',             power: 97, strength: 88, speed: 86, defense: 88, intelligence: 95, popularity: 90, color: '#9a4a4a' },
    { name: 'Konan',            power: 84, strength: 75, speed: 82, defense: 78, intelligence: 88, popularity: 81, color: '#5a82b5' },
    { name: 'Kisame',           power: 90, strength: 95, speed: 80, defense: 88, intelligence: 78, popularity: 75, color: '#3a6a8a' },
    { name: 'Shino Aburame',    power: 72, strength: 62, speed: 70, defense: 75, intelligence: 88, popularity: 62, color: '#6a7a5a' },
    { name: 'Kiba Inuzuka',     power: 78, strength: 78, speed: 86, defense: 70, intelligence: 70, popularity: 78, color: '#a45a3a' },
    { name: 'Choji Akimichi',   power: 80, strength: 92, speed: 60, defense: 88, intelligence: 70, popularity: 75, color: '#c47a3a' },
    { name: 'Ino Yamanaka',     power: 70, strength: 65, speed: 75, defense: 68, intelligence: 82, popularity: 84, color: '#dfaa3a' },
    { name: 'Tenten',           power: 75, strength: 72, speed: 82, defense: 70, intelligence: 76, popularity: 70, color: '#a4493a' },
    { name: 'Killer Bee',       power: 91, strength: 90, speed: 86, defense: 85, intelligence: 80, popularity: 86, color: '#5a4a8a' },
    { name: 'Minato Namikaze',  power: 96, strength: 84, speed: 99, defense: 82, intelligence: 97, popularity: 96, color: '#dfb84a' },
    { name: 'Obito Uchiha',     power: 94, strength: 82, speed: 90, defense: 84, intelligence: 92, popularity: 88, color: '#7a3a4a' },
    { name: 'Nagato',           power: 95, strength: 80, speed: 82, defense: 86, intelligence: 96, popularity: 84, color: '#a44a4a' },
    { name: 'Yamato',           power: 84, strength: 76, speed: 80, defense: 85, intelligence: 86, popularity: 72, color: '#5a7a4a' },
    { name: 'Asuma Sarutobi',   power: 84, strength: 82, speed: 80, defense: 80, intelligence: 84, popularity: 76, color: '#3a5a3a' },
    { name: 'Kurenai Yuhi',     power: 80, strength: 70, speed: 78, defense: 76, intelligence: 88, popularity: 74, color: '#8a4a5a' },
  ];

  // Build a 52-card deck — assign suit + rank cycling
  function buildDeck() {
    const deck = [];
    // Cycle 13 ranks * 4 suits = 52; reuse characters if needed
    let i = 0;
    for (const suit of SUITS) {
      for (const rank of RANKS) {
        const ch = CHARACTERS[i % CHARACTERS.length];
        deck.push({
          id: `${suit}-${rank}-${i}`,
          suit,
          rank,
          ...ch,
        });
        i++;
      }
    }
    return deck;
  }

  // Stable PRNG
  function rng(seed) {
    let s = seed >>> 0;
    return function () {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }

  function shuffle(arr, seed) {
    const r = rng(seed || Date.now());
    const out = arr.slice();
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(r() * (i + 1));
      [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
  }

  function dealHands(numPlayers, cardsPerPlayer, seed) {
    const deck = shuffle(buildDeck(), seed);
    const hands = [];
    for (let p = 0; p < numPlayers; p++) {
      hands.push(deck.slice(p * cardsPerPlayer, (p + 1) * cardsPerPlayer));
    }
    return hands;
  }

  // Portrait — SVG illustration per character (deterministic from name + color)
  // Used as a graceful fallback instead of attempting real anime art.
  function portraitURL(card) {
    // generate inline SVG data URL — stylized portrait silhouette in their color
    const c = card.color || '#8a4a5a';
    const seed = card.name.split('').reduce((s, ch) => s + ch.charCodeAt(0), 0);
    const r = rng(seed);
    const initial = card.name.split(' ').map(w => w[0]).slice(0, 2).join('');
    const bgAngle = Math.floor(r() * 360);
    const hue1 = c;
    const hue2 = shadeColor(c, -30);
    const hue3 = shadeColor(c, 25);
    const eyeY = 60 + Math.floor(r() * 8);
    const hairStyle = Math.floor(r() * 4);
    const accent = ['#f0d564', '#ff6b6b', '#7ab8ff', '#5ee08a'][Math.floor(r() * 4)];

    const hair = renderHair(hairStyle, hue2, accent);
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 260' preserveAspectRatio='xMidYMid slice'>
      <defs>
        <linearGradient id='bg' x1='0' y1='0' x2='1' y2='1' gradientTransform='rotate(${bgAngle} 0.5 0.5)'>
          <stop offset='0%' stop-color='${hue3}'/>
          <stop offset='60%' stop-color='${hue1}'/>
          <stop offset='100%' stop-color='${hue2}'/>
        </linearGradient>
        <radialGradient id='glow' cx='0.5' cy='0.35' r='0.7'>
          <stop offset='0%' stop-color='rgba(255,255,255,0.45)'/>
          <stop offset='100%' stop-color='rgba(255,255,255,0)'/>
        </radialGradient>
      </defs>
      <rect width='200' height='260' fill='url(#bg)'/>
      <rect width='200' height='260' fill='url(#glow)'/>
      <!-- sparkles -->
      <g fill='${accent}' opacity='0.7'>
        <circle cx='30' cy='40' r='1.5'/>
        <circle cx='170' cy='30' r='2'/>
        <circle cx='160' cy='80' r='1'/>
        <circle cx='40' cy='100' r='1.2'/>
        <circle cx='180' cy='200' r='1.5'/>
        <circle cx='20' cy='180' r='1'/>
      </g>
      <!-- body silhouette -->
      <path d='M40 260 L40 220 Q40 180 100 170 Q160 180 160 220 L160 260 Z' fill='${hue2}'/>
      <path d='M70 230 Q100 215 130 230 L130 260 L70 260 Z' fill='${shadeColor(hue2, -10)}'/>
      <!-- collar -->
      <path d='M80 200 L100 180 L120 200 L100 215 Z' fill='${accent}' opacity='0.5'/>
      <!-- neck -->
      <rect x='90' y='150' width='20' height='25' fill='#f3d6b0' rx='4'/>
      <!-- face -->
      <ellipse cx='100' cy='110' rx='42' ry='50' fill='#f6dec1'/>
      <!-- face shading -->
      <path d='M58 110 Q62 140 100 158 Q138 140 142 110 Q142 90 100 78 Q58 90 58 110 Z' fill='url(#glow)' opacity='0.6'/>
      <!-- hair -->
      ${hair}
      <!-- eyes -->
      <ellipse cx='84' cy='${eyeY + 50}' rx='5' ry='7' fill='#fff'/>
      <ellipse cx='116' cy='${eyeY + 50}' rx='5' ry='7' fill='#fff'/>
      <ellipse cx='84' cy='${eyeY + 51}' rx='3' ry='5' fill='${shadeColor(hue1, -40)}'/>
      <ellipse cx='116' cy='${eyeY + 51}' rx='3' ry='5' fill='${shadeColor(hue1, -40)}'/>
      <circle cx='85' cy='${eyeY + 49}' r='1.2' fill='#fff'/>
      <circle cx='117' cy='${eyeY + 49}' r='1.2' fill='#fff'/>
      <!-- nose -->
      <path d='M100 115 L98 125 L102 125 Z' fill='${shadeColor('#f6dec1', -15)}' opacity='0.6'/>
      <!-- mouth -->
      <path d='M93 135 Q100 140 107 135' stroke='${shadeColor(hue1, -50)}' stroke-width='1.5' fill='none' stroke-linecap='round'/>
      <!-- cheek blush -->
      <ellipse cx='78' cy='128' rx='6' ry='3' fill='${accent}' opacity='0.25'/>
      <ellipse cx='122' cy='128' rx='6' ry='3' fill='${accent}' opacity='0.25'/>
      <!-- accent mark -->
      <text x='100' y='248' text-anchor='middle' font-family='monospace' font-size='9' fill='rgba(255,255,255,0.5)' font-weight='700'>${escapeXML(initial)}</text>
    </svg>`;
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }

  function renderHair(style, color, accent) {
    switch (style) {
      case 0: // spiky
        return `<path d='M60 90 Q55 60 75 50 L80 70 L92 45 L98 70 L108 45 L116 72 L130 50 L132 70 Q145 60 140 90 Q145 95 138 100 L62 100 Q55 95 60 90 Z' fill='${color}'/>
          <path d='M70 65 L80 50 L78 70 Z M115 50 L125 65 L120 72 Z' fill='${accent}' opacity='0.5'/>`;
      case 1: // long flow
        return `<path d='M58 95 Q52 65 75 55 Q95 45 125 50 Q148 60 144 95 L150 160 Q140 165 135 130 L132 110 L68 110 L65 130 Q60 165 50 160 Z' fill='${color}'/>
          <path d='M75 70 L100 60 L125 70 L125 85 L75 85 Z' fill='${accent}' opacity='0.3'/>`;
      case 2: // bowl/curtain
        return `<path d='M58 100 Q55 70 80 58 Q100 50 120 58 Q145 70 142 100 L140 115 L60 115 Z' fill='${color}'/>
          <path d='M70 95 L100 70 L130 95' stroke='${accent}' stroke-width='1.5' fill='none' opacity='0.5'/>`;
      case 3: // tied/headband
        return `<path d='M58 95 Q55 60 100 55 Q145 60 142 95 L140 105 L60 105 Z' fill='${color}'/>
          <rect x='55' y='95' width='90' height='8' fill='${accent}'/>
          <circle cx='100' cy='99' r='3' fill='${shadeColor(accent, -30)}'/>`;
      default:
        return '';
    }
  }

  function shadeColor(hex, percent) {
    const h = hex.replace('#', '');
    const num = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
    let r = (num >> 16) + percent;
    let g = ((num >> 8) & 0xff) + percent;
    let b = (num & 0xff) + percent;
    r = Math.max(0, Math.min(255, r));
    g = Math.max(0, Math.min(255, g));
    b = Math.max(0, Math.min(255, b));
    return '#' + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
  }

  function escapeXML(s) {
    return s.replace(/[<>&'"]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));
  }

  function genRoomCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let s = '';
    for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return 'ANIME-' + s;
  }

  window.TC = {
    SUITS, SUIT_GLYPH, SUIT_RED, RANKS, STATS,
    CHARACTERS, buildDeck, shuffle, dealHands, portraitURL, genRoomCode, rng
  };
})();
